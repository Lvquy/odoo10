# -*- coding: utf-8 -*-
from odoo import api, fields, models,_
from odoo.exceptions import UserError
import datetime, time
from datetime import date
import dateutil.parser
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT


class HR(models.Model):
    _inherit = 'hr.employee'

    thiet_bi = fields.One2many('tai.san','nguoi_bao_quan',string='Thiet bi', readonly=True)
    sms_birthday = fields.Boolean(string='Tự động gửi SMS chúc mừng sinh nhật.', default=False)

    @api.onchange('sms_birthday')
    def check_sms(self):
        if self.sms_birthday is True:
            if not self.birthday or not self.mobile_phone:
                raise UserError('Chú ý! Cần có thông tin ngày sinh và SĐT')
class Lichsu(models.Model):
    _name='lich.su'

    ref_hr = fields.Many2one('tai.san')
    thiet_bi = fields.Char(related='ref_hr.name')
    note = fields.Text(string='Note')
