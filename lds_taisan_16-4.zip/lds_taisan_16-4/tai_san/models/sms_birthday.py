# -*- coding:utf-8 -*-
from odoo import models, fields, api
import datetime
from datetime import date
import pushbullet
import dateutil.parser
class Birthday(models.Model):
    _inherit = 'hr.employee'

    def auto_sms(self):
        if self.env['api.key'].search([], limit=1).status == 'on':
            API_KEY = self.env['api.key'].search([], limit=1).api_key
            # print API_KEY
            pb = pushbullet.Pushbullet(API_KEY)
            device = pb.devices[0]
            # pb.push_sms(device, '1414', 'tttb')

            data = self.env['hr.employee']
            id_all = data.search([('sms_birthday','=',True)])
            # id_need = data.browse(id_all)
            # # print id_need
            for i in id_all:
                day = date.today().day
                month = date.today().month
                birthday = i.birthday
                birthday_day = dateutil.parser.parse(birthday).day
                birthday_month = dateutil.parser.parse(birthday).month
                if birthday_month == month and birthday_day == day:
                    id_need = data.browse(i.id)
                    print id_need.name
                    mobile= id_need.mobile_phone
                    sms = "Chúc bạn " + str(id_need.name) + " Sinh nhật vui vẻ! " + str(birthday)
                    a =self.env['api.key'].search([('status','=','on')], limit=1)
                    a.count += 1
                    pb.push_sms(device, mobile, sms)